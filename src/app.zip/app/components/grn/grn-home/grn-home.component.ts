import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-home',
  templateUrl: './grn-home.component.html',
  styleUrls: ['./grn-home.component.css']
})
export class GrnHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
