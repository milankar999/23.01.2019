import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-without-po-lineitems-edit',
  templateUrl: './grn-without-po-lineitems-edit.component.html',
  styleUrls: ['./grn-without-po-lineitems-edit.component.css']
})
export class GrnWithoutPoLineitemsEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
