import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-without-po-lineitems',
  templateUrl: './grn-without-po-lineitems.component.html',
  styleUrls: ['./grn-without-po-lineitems.component.css']
})
export class GrnWithoutPoLineitemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
