import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-without-po-selected-lineitems',
  templateUrl: './grn-without-po-selected-lineitems.component.html',
  styleUrls: ['./grn-without-po-selected-lineitems.component.css']
})
export class GrnWithoutPoSelectedLineitemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
