import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-goods-receive',
  templateUrl: './goods-receive.component.html',
  styleUrls: ['./goods-receive.component.css']
})
export class GoodsReceiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
