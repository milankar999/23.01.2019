import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cash-purchase-contact-product-entry',
  templateUrl: './cash-purchase-contact-product-entry.component.html',
  styleUrls: ['./cash-purchase-contact-product-entry.component.css']
})
export class CashPurchaseContactProductEntryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
