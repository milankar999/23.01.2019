import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-select-transition-type',
  templateUrl: './grn-select-transition-type.component.html',
  styleUrls: ['./grn-select-transition-type.component.css']
})
export class GrnSelectTransitionTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
