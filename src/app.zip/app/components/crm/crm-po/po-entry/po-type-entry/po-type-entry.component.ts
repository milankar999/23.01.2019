import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-type-entry',
  templateUrl: './po-type-entry.component.html',
  styleUrls: ['./po-type-entry.component.css']
})
export class PoTypeEntryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
