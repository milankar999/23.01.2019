import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-entry-edit-selected-product',
  templateUrl: './po-entry-edit-selected-product.component.html',
  styleUrls: ['./po-entry-edit-selected-product.component.css']
})
export class PoEntryEditSelectedProductComponent implements OnInit {
  model : any={};
  constructor() { }

  ngOnInit() {
  }

}
