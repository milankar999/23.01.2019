import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-entry',
  templateUrl: './po-entry.component.html',
  styleUrls: ['./po-entry.component.css']
})
export class PoEntryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
