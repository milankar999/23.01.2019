import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-modification',
  templateUrl: './po-modification.component.html',
  styleUrls: ['./po-modification.component.css']
})
export class PoModificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
