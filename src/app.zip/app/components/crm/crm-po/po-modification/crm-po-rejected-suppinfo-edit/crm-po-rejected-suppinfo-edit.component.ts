import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crm-po-rejected-suppinfo-edit',
  templateUrl: './crm-po-rejected-suppinfo-edit.component.html',
  styleUrls: ['./crm-po-rejected-suppinfo-edit.component.css']
})
export class CrmPoRejectedSuppinfoEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
