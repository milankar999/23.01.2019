import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crm-po-rejected-lineitem-edit',
  templateUrl: './crm-po-rejected-lineitem-edit.component.html',
  styleUrls: ['./crm-po-rejected-lineitem-edit.component.css']
})
export class CrmPoRejectedLineitemEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
