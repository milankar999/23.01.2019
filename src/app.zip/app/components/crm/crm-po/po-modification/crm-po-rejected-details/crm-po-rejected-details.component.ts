import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crm-po-rejected-details',
  templateUrl: './crm-po-rejected-details.component.html',
  styleUrls: ['./crm-po-rejected-details.component.css']
})
export class CrmPoRejectedDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
