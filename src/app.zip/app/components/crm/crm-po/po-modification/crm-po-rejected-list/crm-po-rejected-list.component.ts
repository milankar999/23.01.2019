import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crm-po-rejected-list',
  templateUrl: './crm-po-rejected-list.component.html',
  styleUrls: ['./crm-po-rejected-list.component.css']
})
export class CrmPoRejectedListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
