import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crm-po',
  templateUrl: './crm-po.component.html',
  styleUrls: ['./crm-po.component.css']
})
export class CrmPoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
