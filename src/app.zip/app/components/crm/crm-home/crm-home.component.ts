import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crm-home',
  templateUrl: './crm-home.component.html',
  styleUrls: ['./crm-home.component.css']
})
export class CrmHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
