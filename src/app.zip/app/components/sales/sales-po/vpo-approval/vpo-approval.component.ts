import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vpo-approval',
  templateUrl: './vpo-approval.component.html',
  styleUrls: ['./vpo-approval.component.css']
})
export class VpoApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
