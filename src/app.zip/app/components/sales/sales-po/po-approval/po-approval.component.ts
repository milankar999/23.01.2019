import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-approval',
  templateUrl: './po-approval.component.html',
  styleUrls: ['./po-approval.component.css']
})
export class PoApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
