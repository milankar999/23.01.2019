import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-po-approval-details',
  templateUrl: './sales-po-approval-details.component.html',
  styleUrls: ['./sales-po-approval-details.component.css']
})
export class SalesPoApprovalDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
