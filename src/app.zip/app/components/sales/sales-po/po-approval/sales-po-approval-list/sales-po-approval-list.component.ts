import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-po-approval-list',
  templateUrl: './sales-po-approval-list.component.html',
  styleUrls: ['./sales-po-approval-list.component.css']
})
export class SalesPoApprovalListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
