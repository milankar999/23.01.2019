import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-po-approval-support-info',
  templateUrl: './sales-po-approval-support-info.component.html',
  styleUrls: ['./sales-po-approval-support-info.component.css']
})
export class SalesPoApprovalSupportInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
