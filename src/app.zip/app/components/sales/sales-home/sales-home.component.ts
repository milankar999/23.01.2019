import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-home',
  templateUrl: './sales-home.component.html',
  styleUrls: ['./sales-home.component.css']
})
export class SalesHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
