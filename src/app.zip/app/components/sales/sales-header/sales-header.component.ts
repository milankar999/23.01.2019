import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-header',
  templateUrl: './sales-header.component.html',
  styleUrls: ['./sales-header.component.css']
})
export class SalesHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
  