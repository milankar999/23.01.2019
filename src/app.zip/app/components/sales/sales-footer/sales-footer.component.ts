import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-footer',
  templateUrl: './sales-footer.component.html',
  styleUrls: ['./sales-footer.component.css']
})
export class SalesFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
