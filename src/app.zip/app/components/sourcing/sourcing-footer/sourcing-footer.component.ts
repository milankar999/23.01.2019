import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-footer', 
  templateUrl: './sourcing-footer.component.html',
  styleUrls: ['./sourcing-footer.component.css']
})
export class SourcingFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
