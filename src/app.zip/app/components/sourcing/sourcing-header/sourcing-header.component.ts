import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-header',
  templateUrl: './sourcing-header.component.html',
  styleUrls: ['./sourcing-header.component.css']
})
export class SourcingHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
