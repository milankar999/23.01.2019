import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-cpo-pending-details',
  templateUrl: './sourcing-cpo-pending-details.component.html',
  styleUrls: ['./sourcing-cpo-pending-details.component.css']
})
export class SourcingCpoPendingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
