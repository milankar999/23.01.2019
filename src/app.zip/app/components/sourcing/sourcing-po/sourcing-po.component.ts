import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-po',
  templateUrl: './sourcing-po.component.html',
  styleUrls: ['./sourcing-po.component.css']
})
export class SourcingPoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
