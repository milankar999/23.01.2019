import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-cpo-new-vendor',
  templateUrl: './sourcing-cpo-new-vendor.component.html',
  styleUrls: ['./sourcing-cpo-new-vendor.component.css']
})
export class SourcingCpoNewVendorComponent implements OnInit {
model:any={}
  constructor() { }

  ngOnInit() {
  }

}
 