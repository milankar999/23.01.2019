import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-cpo-lineitem-edit',
  templateUrl: './sourcing-cpo-lineitem-edit.component.html',
  styleUrls: ['./sourcing-cpo-lineitem-edit.component.css']
})
export class SourcingCpoLineitemEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
