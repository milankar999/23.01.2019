import { Component, OnInit} from '@angular/core';




@Component({
  selector: 'app-sourcing-cpo-pending-list',
  templateUrl: './sourcing-cpo-pending-list.component.html',
  styleUrls: ['./sourcing-cpo-pending-list.component.css']
})
export class SourcingCpoPendingListComponent implements OnInit {
  

  constructor() { }

  ngOnInit() {
  }

}
