import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-check-vendor-info',
  templateUrl: './sourcing-vpo-check-vendor-info.component.html',
  styleUrls: ['./sourcing-vpo-check-vendor-info.component.css']
})
export class SourcingVpoCheckVendorInfoComponent implements OnInit {
  model:any={}
  constructor() { }

  ngOnInit() {
  }

}




