import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-cpo-vendor-product',
  templateUrl: './sourcing-cpo-vendor-product.component.html',
  styleUrls: ['./sourcing-cpo-vendor-product.component.css']
})
export class SourcingCpoVendorProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
