import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-add-contactperson-info',
  templateUrl: './sourcing-vpo-add-contactperson-info.component.html',
  styleUrls: ['./sourcing-vpo-add-contactperson-info.component.css']
})
export class SourcingVpoAddContactpersonInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
