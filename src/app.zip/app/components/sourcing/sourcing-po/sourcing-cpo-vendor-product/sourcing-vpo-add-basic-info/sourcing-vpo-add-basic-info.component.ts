import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-add-basic-info',
  templateUrl: './sourcing-vpo-add-basic-info.component.html',
  styleUrls: ['./sourcing-vpo-add-basic-info.component.css']
})
export class SourcingVpoAddBasicInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
