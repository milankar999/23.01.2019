import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing',
  templateUrl: './sourcing.component.html',
  styleUrls: ['./sourcing.component.css']
})
export class SourcingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
