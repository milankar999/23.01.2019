export interface SourcingCpoPending {
    id: string,
    customer:string,
    customer_contact_person: string,
    customer_po_no: string,
    delivery_date:string,
}
