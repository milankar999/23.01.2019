export interface CpoPendingDetails {
id: string,
product_title: string,
description:string,
model: string,
brand: string,
product_code: string,
part_no: string,
hsn_code: string,
pack_size: string,
gst: number,
uom: string,
quantity: string,

}