export interface SalePoApprovalSupportpost {
    rejection_reason: string,  
}
