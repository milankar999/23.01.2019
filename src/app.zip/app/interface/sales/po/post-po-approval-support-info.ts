export interface PostPoApprovalSupportInfo {
    assign_to:string
}
