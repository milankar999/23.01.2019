export interface LoginInterface {
    token: string;
    type: string;
}
