export interface PoEntryNewCustomer {
        id:string ,
        name:string ,
        location:string ,
        code:string ,
        city:string ,
        state:string ,
    }
    

