export interface PostProductSelected {
    quotation_lineitems:string
}

