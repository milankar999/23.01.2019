export interface CrmPoRejectLineitemsDelete {
    id:string;
}

