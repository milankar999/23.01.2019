export interface SupportingInfo {
    address:  string,
    billing_address:string,
    shipping_address: string,
    inco_term: string,
    payment_term: number
}
