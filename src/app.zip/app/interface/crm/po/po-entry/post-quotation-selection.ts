export interface PostQuotationSelection {
    quotation_no:string;
}
