export interface QuotationSelectionPage 
{   
    quotation_id:string
    quotation_no:string,
    customer_contact_person:string,
    name:string,
    quotation_date:Date,
    rfp:string,
    rfp_no:string,
    enquiry_reference:string,
}
