export interface PoEntryCustomerTable {
    name:string;
    mobileNo1: Number;
    mobileNo2: Number;
    email1: string;
    email2: string;
}
