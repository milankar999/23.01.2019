export interface PoEntryReciver {
    id:  string,
    person_name:string,
    mobileNo1:string,         
    mobileNo2:string,
    email1:string,
    email2:string,
    department_name:string,
}
