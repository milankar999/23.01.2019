export interface PoApprovalSupportInfo {
    username:string
}

