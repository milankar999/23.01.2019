import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vpo-approval-list',
  templateUrl: './vpo-approval-list.component.html',
  styleUrls: ['./vpo-approval-list.component.css']
})
export class VpoApprovalListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
