import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vpo-approval-details',
  templateUrl: './vpo-approval-details.component.html',
  styleUrls: ['./vpo-approval-details.component.css']
})
export class VpoApprovalDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
