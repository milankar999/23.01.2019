import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vpo-approval-info',
  templateUrl: './vpo-approval-info.component.html',
  styleUrls: ['./vpo-approval-info.component.css']
})
export class VpoApprovalInfoComponent implements OnInit {
  model:any={}
  constructor() { }

  ngOnInit() {
  }

}
