import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-po',
  templateUrl: './sales-po.component.html',
  styleUrls: ['./sales-po.component.css']
})
export class SalesPoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
