import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crm-footer',
  templateUrl: './crm-footer.component.html',
  styleUrls: ['./crm-footer.component.css']
})
export class CrmFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
