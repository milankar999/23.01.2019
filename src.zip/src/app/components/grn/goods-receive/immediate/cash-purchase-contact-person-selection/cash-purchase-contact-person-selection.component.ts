import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cash-purchase-contact-person-selection',
  templateUrl: './cash-purchase-contact-person-selection.component.html',
  styleUrls: ['./cash-purchase-contact-person-selection.component.css']
})
export class CashPurchaseContactPersonSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
