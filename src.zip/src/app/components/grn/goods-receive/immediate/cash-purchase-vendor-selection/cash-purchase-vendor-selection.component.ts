import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cash-purchase-vendor-selection',
  templateUrl: './cash-purchase-vendor-selection.component.html',
  styleUrls: ['./cash-purchase-vendor-selection.component.css']
})
export class CashPurchaseVendorSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
