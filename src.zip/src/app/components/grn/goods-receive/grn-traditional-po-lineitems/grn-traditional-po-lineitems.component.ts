import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-traditional-po-lineitems',
  templateUrl: './grn-traditional-po-lineitems.component.html',
  styleUrls: ['./grn-traditional-po-lineitems.component.css']
})
export class GrnTraditionalPoLineitemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
