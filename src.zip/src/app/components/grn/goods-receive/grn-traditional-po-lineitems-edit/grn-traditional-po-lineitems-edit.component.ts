import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-traditional-po-lineitems-edit',
  templateUrl: './grn-traditional-po-lineitems-edit.component.html',
  styleUrls: ['./grn-traditional-po-lineitems-edit.component.css']
})
export class GrnTraditionalPoLineitemsEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
