import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-traditional-po-selected-lineitems',
  templateUrl: './grn-traditional-po-selected-lineitems.component.html',
  styleUrls: ['./grn-traditional-po-selected-lineitems.component.css']
})
export class GrnTraditionalPoSelectedLineitemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
