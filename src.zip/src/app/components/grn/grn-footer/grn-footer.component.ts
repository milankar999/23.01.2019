import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grn-footer',
  templateUrl: './grn-footer.component.html',
  styleUrls: ['./grn-footer.component.css']
})
export class GrnFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
