import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-receive',
  templateUrl: './invoice-receive.component.html',
  styleUrls: ['./invoice-receive.component.css']
})
export class InvoiceReceiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
