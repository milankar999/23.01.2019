import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-list',
  templateUrl: './sourcing-vpo-list.component.html',
  styleUrls: ['./sourcing-vpo-list.component.css']
})
export class SourcingVpoListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
