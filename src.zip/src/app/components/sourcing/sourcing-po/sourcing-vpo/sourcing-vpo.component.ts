import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo',
  templateUrl: './sourcing-vpo.component.html',
  styleUrls: ['./sourcing-vpo.component.css']
})
export class SourcingVpoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
