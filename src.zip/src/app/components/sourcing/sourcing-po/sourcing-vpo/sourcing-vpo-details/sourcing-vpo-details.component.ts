import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-details',
  templateUrl: './sourcing-vpo-details.component.html',
  styleUrls: ['./sourcing-vpo-details.component.css']
})
export class SourcingVpoDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
