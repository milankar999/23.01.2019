import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-signature',
  templateUrl: './sourcing-vpo-signature.component.html',
  styleUrls: ['./sourcing-vpo-signature.component.css']
})
export class SourcingVpoSignatureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
