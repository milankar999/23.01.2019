import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-receiver-info',
  templateUrl: './sourcing-vpo-receiver-info.component.html',
  styleUrls: ['./sourcing-vpo-receiver-info.component.css']
})
export class SourcingVpoReceiverInfoComponent implements OnInit {
  model:any={}
  constructor() { }

  ngOnInit() {
  }

}
