import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-add-basic-info',
  templateUrl: './sourcing-vpo-add-basic-info.component.html',
  styleUrls: ['./sourcing-vpo-add-basic-info.component.css']
})
export class SourcingVpoAddBasicInfoComponent implements OnInit {
  model:any={}
  
  
  //advance_persentage=10/100;

 //var price=150;
  //var sale=25;

  //document.write("original price: $"+ price.toFixed(2)+"<br>0");
  //document.write("sale: $"+sale+"%<br>")

  constructor() { }

  ngOnInit() {
  }

}
