import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-requester-info',
  templateUrl: './sourcing-vpo-requester-info.component.html',
  styleUrls: ['./sourcing-vpo-requester-info.component.css']
})
export class SourcingVpoRequesterInfoComponent implements OnInit {
  model:any={}

  constructor() { }

  ngOnInit() {
  }

}
