import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-terms-conditions',
  templateUrl: './sourcing-vpo-terms-conditions.component.html',
  styleUrls: ['./sourcing-vpo-terms-conditions.component.css']
})
export class SourcingVpoTermsConditionsComponent implements OnInit {
  model:any={}
  constructor() { }

  ngOnInit() {
  }

}
