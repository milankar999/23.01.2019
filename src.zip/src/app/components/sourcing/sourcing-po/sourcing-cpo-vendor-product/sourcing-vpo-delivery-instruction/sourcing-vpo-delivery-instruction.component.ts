import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-vpo-delivery-instruction',
  templateUrl: './sourcing-vpo-delivery-instruction.component.html',
  styleUrls: ['./sourcing-vpo-delivery-instruction.component.css']
})
export class SourcingVpoDeliveryInstructionComponent implements OnInit {
  model:any={}
  constructor() { }

  ngOnInit() {
  }

}
