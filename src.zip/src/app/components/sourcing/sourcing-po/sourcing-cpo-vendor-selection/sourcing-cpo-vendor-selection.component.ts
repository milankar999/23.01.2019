import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-cpo-vendor-selection',
  templateUrl: './sourcing-cpo-vendor-selection.component.html',
  styleUrls: ['./sourcing-cpo-vendor-selection.component.css']
})
export class SourcingCpoVendorSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
