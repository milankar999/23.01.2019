import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcing-home',
  templateUrl: './sourcing-home.component.html',
  styleUrls: ['./sourcing-home.component.css']
})
export class SourcingHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
